# MTK 2.0 Android UI Overhaul

The current MTK 2.0 Android interface is a full UI overhaul of the older mobile layout. The goal was not simply to change colours or make the app look newer. The older interface exposed several controls directly on the Home screen, while a number of important Android workflows were either incomplete, scattered across separate screens, or difficult to understand from the UI alone.

The new interface reorganizes those existing capabilities into a clearer mobile workflow while keeping the familiar MTK 2.0 identity( two previews has been added to experience the UI with aded simulation the log shown in preview are not a full presentation of the actual logging systems) Read flash,write are under development and will be added soon.

---

## Why the old UI needed an overhaul

The older UI already had the basic MTK 2.0 structure:

- MTK 2.0 header and build badge
- device status card and status ring
- chipset selector
- execution-mode selector
- Stock DA option
- CONNECT
- BOOT DA
- READ
- FLASH
- Console Output
- Files
- STOP / CLEAR
- COPY / LOG CENTER / SAVE

That layout worked as a development interface, but it had several usability problems.

### Configuration occupied too much of the Home screen

The older Home screen exposed the chipset and execution-mode selectors as separate full-width controls. This made configuration feel like part of the main operating surface even though those settings are normally changed less often than CONNECT, BOOT DA, READ or FLASH.

The new UI replaces those separate selectors with one compact configuration summary on Home. Tapping it opens **Connection Setup**, where the full configuration can be changed without permanently taking space away from the main screen.

---

### Inactive chipset-family stubs were visible

The older selector exposed entries such as MediaTek together with chipset-family stubs that were not active Android implementations.

The new UI shows the currently active family clearly as:

**Auto-Detect MediaTek (MTK)**

This avoids presenting unfinished families as if they were normal selectable operating modes.

---

### Execution modes were hidden inside a normal spinner

The older interface used a standard Android selector for:

- BootROM Basic
- BootROM Bypass (Payload)
- BROM / Transport Diagnostics

That worked, but it did not make the difference between the modes especially clear.

The new **Connection Setup** screen gives each execution mode its own visible selection row. The currently selected mode is immediately recognizable, and the Home configuration card also shows the active mode without reopening the sheet.

---

### Session options were not independently controllable from the UI

Some optional session checks existed in the Android flow but were not presented as clean independent user options.

The overhauled UI adds separate controls for:

#### DA capability queries

Optional capability/status information that can be enabled when additional diagnostic visibility is wanted.

#### Pre-DA2 storage probe

Optional early storage identification for eMMC, NAND, NOR or UFS.

#### Preload partition table after DA2

Optional GPT/partition-table discovery during startup.

When GPT preload is disabled, the Storage screen can still discover the partition table when it actually needs it. This means partition discovery is not forced to happen during every startup.

These options are independent. Enabling one does not automatically enable the others.

---

## Home screen: old vs new

| Older UI | Current overhauled UI |
| --- | --- |
| Separate chipset spinner | Compact MTK configuration card |
| Separate execution-mode spinner | Active mode shown directly in the configuration card |
| Stock DA mixed with Home configuration | Stock DA moved into Connection Setup |
| Files existed as a separate utility | Files has a permanent shortcut beside the configuration card |
| CONNECT / BOOT DA / READ / FLASH | Preserved as the main Home actions |
| Console occupied the remaining Home area | Console remains on Home with its own controls |
| Limited secondary navigation | Added Home overflow navigation |
| Mostly phone-sized fixed presentation | Adaptive current-window layout |

The new Home screen is therefore more of an **operating dashboard** and less of a settings page.

The main actions remain directly accessible:

- CONNECT
- BOOT DA
- READ
- FLASH

The status card and MTK 2.0 visual identity remain familiar, while configuration and secondary screens are moved out of the primary action area.

---

# Connection Setup

Connection Setup is one of the largest changes in the overhaul.

Instead of leaving multiple selectors and policy controls permanently on Home, they are grouped into one configuration surface.

It currently contains:

### Device Family

Shows the active Android implementation:

**Auto-Detect MediaTek (MTK)**

### Execution Mode

- BootROM Basic
- BootROM Bypass (Payload)
- BROM / Transport Diagnostics

### DA Policy

- Use stock DA

### Session Options

- DA capability queries
- Pre-DA2 storage probe
- Preload partition table after DA2

The selected configuration is reflected back on Home, so reopening Connection Setup is not required just to check the active mode.

---

# Storage UI overhaul

One of the biggest limitations of the older interface was that **READ** and **FLASH** existed on Home before there was a complete unified Android storage workspace behind them.

The newer UI turns storage operations into a dedicated workflow instead of treating READ and FLASH as isolated buttons.

The Storage screen now has three main modes:

- **READ**
- **WRITE**
- **ERASE**

They share one consistent workspace rather than using unrelated screens for each action.

## Target selection

Depending on the operation, the UI can present appropriate target choices such as:

- selected partitions
- all discovered partitions
- storage region
- sector range
- byte range / offset

Partition-based operations use the discovered partition list instead of asking the user to manually remember partition names.

The partition area also includes search/filtering so a large GPT does not become an unusable wall of entries.

---

## Read / backup workflow

The Read UI now has a clear place for:

- choosing the target
- selecting partitions or a range
- choosing the output destination
- reviewing the operation
- following progress while it runs

This replaces the older situation where the Home READ control existed without a complete dedicated Android read workspace.

---

## Write workflow

Write now has its own configuration path instead of sharing the old generic FLASH warning-only experience.

The UI provides a visible place for:

- selecting the exact target
- choosing the source image
- reviewing the operation before starting
- explicitly acknowledging destructive changes
- monitoring the active operation

The intention is to make the target and source obvious before the user starts a write.

---

## Erase workflow

Erase is presented separately from Write.

The UI distinguishes between an explicit partition erase and a range-based erase rather than presenting erase as a vague generic action.

Destructive operations require an explicit acknowledgement in the UI.

---

# Operation review and running state

Storage operations no longer jump directly from configuration to an opaque background action.

The new UI introduces a visible workflow:

**Configure → Review → Run**

During an active operation, the Storage screen can show:

- operation name
- current status
- progress
- live console output
- Log Center access
- CANCEL

This keeps operation information visible in the same place where the operation was configured.

---

# Operations screen

The overhaul adds a dedicated **Operations** screen.

Its purpose is to give the growing Android feature set a proper navigation structure instead of trying to place every possible action on Home.

The screen groups related capabilities into sections such as:

- Read / Backup
- Write / Erase
- Partitions / Device
- BROM / Memory
- DA facilities
- Other tools

Home keeps only the actions needed most often, while less common tools remain discoverable through Operations.

---

# Device & Readiness

The older UI relied heavily on Console Output to explain what state the current session had reached.

The new **Device & Readiness** screen gives that information its own place.

It separates:

- current readiness state
- attained device/session information
- completed stages

from the scrolling console.

This makes it easier to answer a simple question — *what is currently ready?* — without reading through the entire session log.

---

# Saved Results

The overhauled UI adds a dedicated **Saved Results** screen for recent output/recovered artifacts.

Previously, completed work did not have a first-class result surface in the UI.

The new screen gives results their own location rather than mixing them into Home or relying only on console text.

---

# Files screen improvements

The older Files screen already supported manual selections such as:

- DA
- SLA AUTH
- exploit payload
- preloader

However, clearing selections was handled as a broader **CLEAR MANUAL SELECTIONS** action.

The new Files screen gives each file slot its own **CLEAR** control.

This means a user can replace or remove one manual override without destroying the other selected files.

The current Files screen also makes the role of each selected file clearer while keeping automatic assets untouched when no manual override is chosen.

---

# Log Center

Log Center existed before the UI overhaul, so it was not added from nothing.

The overhaul instead makes it a more consistent part of the whole app.

The current Log Center keeps two user-facing views:

- **SESSION REPORT**
- **CORE TRACE**

with the familiar:

- COPY
- CLEAR
- SAVE

controls.

The Home screen also keeps Console Output, while Log Center is available both from Home and from active operation screens.

This creates a clearer separation:

**Home Console**  
Quick live session narrative.

**Session Report**  
Compact session-oriented view.

**Core Trace**  
More detailed chronological view.

The overhaul focuses on making these views easier to reach and easier to understand rather than exposing internal logging implementation details to the user.

---

# Home navigation

The old Home screen had fewer destinations and relied more heavily on direct buttons.

The overhauled Home screen adds a compact overflow menu for secondary screens.

Current navigation includes:

- Operations
- Files
- Log Center
- Device & Readiness
- Saved Results
- About

This prevents Home from becoming a long grid of buttons as more Android functionality is added.

---

# Visual overhaul

The new UI keeps the original MTK 2.0 dark appearance but applies it more consistently across the app.

The visual system now uses the same language across Home, Storage, Files, Log Center, Device & Readiness, Operations and Saved Results:

- dark glass-like surfaces
- violet and cyan accents
- compact cards
- consistent corner radii
- consistent spacing
- clearer section titles
- restrained monospace secondary text
- clearer selected states
- larger and more consistent touch targets
- fixed action/footer areas where appropriate
- scrollable content separated from important controls

The overhaul deliberately kept the MTK 2.0 brand mark, dark theme and core Home actions rather than replacing the application with a completely unrelated visual style.

---

# Adaptive layout

The original interface was primarily arranged around a normal phone-sized window.

The current UI also adapts to the available Android app window.

### Compact phone windows

The familiar phone proportions are preserved.

### Wider phones, tablets and unfolded devices

Content is width-constrained instead of stretching every card across the complete display.

### Short windows and split-screen

Screens that can overflow vertically allow the content area to scroll while important controls remain usable.

### Large fonts

Layouts are designed to allow text wrapping instead of assuming one fixed screen width.

This allows the same UI to remain usable across phones, tablets, foldables and resizable Android windows without simply scaling the entire interface up.

---

# What was preserved

The overhaul was intentionally not a replacement of everything users already knew.

The following parts of the original Android UI were retained and integrated into the new structure:

- MTK 2.0 branding
- original dark violet/cyan visual identity
- status card and status indicator
- CONNECT
- BOOT DA
- READ
- FLASH
- Console Output
- Files
- STOP
- CLEAR
- Log Center
- Session Report
- Core Trace
- COPY
- SAVE
- manual DA / AUTH / payload / preloader selection

The difference is that these controls now sit inside a much more complete Android navigation and workflow structure.

---

# UI overhaul summary

| Area | Older UI | Current UI |
| --- | --- | --- |
| Home configuration | Full-width chipset + mode selectors | Compact configuration card + Connection Setup |
| Device families | MTK plus visible inactive stubs | Active MTK implementation shown clearly |
| Execution modes | Spinner | Dedicated Basic / Bypass / Diagnostics selection |
| Stock DA | Home-level option | Dedicated DA Policy section |
| Optional session checks | Not independently exposed | Three independent session options |
| READ | Home action without full dedicated workflow | Shared Storage workspace |
| FLASH / WRITE | Home action with limited UI flow | Dedicated Write configuration/review/run flow |
| ERASE | No complete shared UI | Dedicated Erase mode in Storage |
| Partitions | No complete unified selection workspace | Searchable discovered-partition UI |
| Operation review | Limited | Configure → Review → Run |
| Operation progress | Mainly console/state feedback | Dedicated running panel + progress + live console |
| Files clearing | Broad manual-selection clear | Individual Clear per file slot |
| Device state | Mostly inferred from Home/console | Dedicated Device & Readiness screen |
| Results | No dedicated result surface | Saved Results screen |
| Feature navigation | Home-centric | Operations screen + Home overflow menu |
| Log Center | Already present | Better integrated throughout the app |
| Large-screen handling | Phone-oriented | Adaptive window sizing |
| Short-screen handling | Limited | Controlled scrolling/overflow support |

---

# Current UI direction

The current design treats Home as the fast operating surface:

**status → configuration → main actions → live console**

Everything that does not need to remain permanently visible is moved into a dedicated screen or configuration surface.

That is the main reason for the overhaul: the Android project grew beyond the point where a single development-style Home screen could present every control clearly.

The newer UI gives each major task its own place while keeping the most important session actions immediately accessible.
