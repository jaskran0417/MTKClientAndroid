# MTK 2.0 Android — Storage evidence and limited previews
Prepared: 2026-11-12 | Status: CANDIDATE PACKAGE, not a release.

This archive is meant for reviewing a possible next GitHub development update. It is NOT an APK, a source release, a live device capture, a full Android-app preview, or evidence that an unbuilt source version ran on hardware.

## Recommended public story
After the September 23, 2026 UI overhaul, native Android Storage operations have been exercised against real MediaTek UFS hardware. Selected historical native Core traces show READ, WRITE and ERASE operations reaching PASS. The same record also includes incomplete USB receive cases on some targets. A 256 MiB boot_a + boot_b backup succeeded; other READs failed with short/incomplete receives, including a separate 200 MiB md1img_a attempt. File size alone is not a proven failure cause.

## What is in the package
- Evidence/READ_256MiB_PASS_and_200MiB_FAILURE: source-backed Core Trace showing both outcomes in a historical session. No exactly paired Wire or Session Report was found for this precise 256 MiB successful operation.
- Evidence/READ_128MiB_PASS_paired_Core_and_Wire: historical boot_b 128 MiB PASS with timestamp-matched Core + Wire.
- Evidence/ERASE_READ_WRITE_then_READBACK_FAIL_27Sep: one nvcfg session with 32 MiB ERASE PASS, immediate READ PASS, WRITE PASS, then later READ incomplete. Core + Wire excerpts; no native exported Session Report from this session was located.
- Evidence/WRITE_and_READBACK_PASS_27Sep: para 512 KiB WRITE PASS and later READ PASS, with Core + Wire.
- Evidence/READ_FAILURE_paired_All_Three_27Sep: nvcfg incomplete READ with exported Core Trace, Session Report and Wire Trace from the same session.
- Evidence/RECENT_READ_FAILURE_11Nov_Core_and_Session_only: additional later nvcfg incomplete READ with Core + Session, but NO same-session Wire export identified. Do not substitute a September or a November 15:40 Wire file for the November 20:10/20:11 session.
- Previews: only TWO self-contained HTML views: (1) historical READ/WRITE/ERASE results, (2) three different logging views from one failure session. No full-app navigation or runnable operations.
- SOURCE_MANIFEST.json: SHA-256 of the unmodified originals and of every generated archive entry except SOURCE_MANIFEST.json itself.

## Attribution and limitations
- All extracted log content comes from existing saved files in Download/Mtk client project. Core and Session evidence are selected text excerpts, not full exports. Wire is timestamp-sampled, with sampled HEX payload bytes omitted.
- Core Trace/Wire pairs are matched by stored filenames and event time windows. The exact 256 MiB PASS is Core-only; the separate 128 MiB PASS has a matched Wire capture.
- PASS means the runtime reported operation completion. Independent cryptographic readback verification is not claimed unless supported by a separate comparison.
- In the nvcfg series, the later incomplete READ does NOT negate the logged earlier ERASE/WRITE PASS, but it prevents claiming a successful post-WRITE verification from that attempt.
- Raw full Wire Traces are intentionally excluded because they can contain payload samples, device/session-specific information and large unrelated records. Original files stay untouched in Downloads.
- No actual v1.5.46 hardware screenshots were included. The HTML previews reproduce the current Android UI structure/styles and use historical evidence. They are interactive offline demonstrations, NOT a running Android APK.
- Nothing here is a safe write/erase instruction or a compatibility guarantee. Avoid posting IMEIs, unique device identifiers, original NVRAM/NVDATA images or full packet payload dumps.

## Public upload suggestion
A dated progress-post archive with these small, clearly limited previews and selected excerpts; do not overwrite the existing September 23 archive, and do not label these historical tests a new stable APK release.
