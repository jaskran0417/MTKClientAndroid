# Evidence index — source-based selection, not a synthetic test run

| Case | Operation evidence | Available native log views | Source date | Caveat |
|---|---|---|---|---|
| READ 256 MiB | boot_a + boot_b two 128 MiB files, PASS; separate md1img_a 200 MiB attempt incomplete | Core only | 2026-09-26 | No matching Session/Wire export for exact 256 MiB PASS |
| READ 128 MiB | boot_b PASS | Core + Wire | 2026-09-26 | Distinct operation from the two-file 256 MiB success |
| ERASE/READ/WRITE | nvcfg ERASE PASS, READ PASS, WRITE PASS, later READ incomplete | Core + Wire | 2026-09-27 | No exported native Session Report for this sequence |
| WRITE/READ | para WRITE PASS and READ PASS, 512 KiB | Core + Wire | 2026-09-27 | PASS does not itself prove independent content comparison |
| READ incomplete | nvcfg failed with short/incomplete receive | Core + Session Report + Wire | 2026-09-27 | Full three-view historical evidence |
| READ incomplete later | nvcfg incomplete after 1,179,648 full-frame bytes; partial physical frame separate | Core + Session Report | 2026-11-11 | No same-session Wire export located |

**Why a comprehensive three-view demonstration is NOT supplied for WRITE and ERASE:** of the available saved SessionReport exports, no time-matched native Session Report was found for the September 27 WRITE/ERASE runs. We do not reconstruct and mislabel one.

**Why the preview is limited:** a narrow set of historical operation-result cards and one two-tab Log Center view with separate Wire Trace evidence illustrate the development work without simulating the Android app or implying that unbuilt source revisions were installed.

**Privacy treatment:** original files are not altered; generated excerpts remove low-level packet HEX data and exclude target identity strings. Review all content again before publishing.

